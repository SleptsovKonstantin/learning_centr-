const arr1 = ['asddsa', 'sdf', 'fdge', 'sdgfd','ff'];

console.log(arr1.sort((a, b) => {
  return a.length - b.length}));